package com.atguigu.threadlocal;

import java.util.Hashtable;
import java.util.Map;
import java.util.Random;

public class ThreadLocalTest {
    public final static Map<String, Object> data = new Hashtable<String, Object>();

    private static Random random = new Random();

    public static class Task implements Runnable{

        @Override
        public void run() {
            Integer i = random.nextInt(1000);
            String name = Thread.currentThread().getName();
            System.out.println("线程【"+ name + "】生成的随机数是：" + i);
            data.put(name, i);

            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            new OrderService().createOrder();
            Object name1 = data.get(name);
            System.out.println("在线程【" + name + "】快结束时取出关联的数据是：" + name1);
        }
    }

    public static void main(String[] args) {
        for(int i = 0; i<3; i++){
            new Thread(new Task()).start();
        }
    }
}
