package com.atguigu.filter;

import javax.servlet.*;
import java.io.IOException;

public class Filter1 implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        System.out.println("Filter1 前置代码");
        chain.doFilter(request, response);
        System.out.println("Filter1 后置代码");
    }

    @Override
    public void destroy() {

    }
}
