import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Test01 {
    public static void main(String[] args) {
        Person p = new Person("张三");
        Class clazz = p.getClass();
        try {
            Field m = clazz.getDeclaredField("name");
            m.setAccessible(true);
            try {
                System.out.println(m.get(p));
            } catch (IllegalAccessException e) {
                e.printStackTrace();
            }
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

    }
}
