package com.atguigu.json;

import com.atguigu.pojo.Person;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.junit.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JsonTest {
    @Test
    public void test1(){
        Person person = new Person(1, "国歌好帅");
        Gson gson = new Gson();
        String personJsonString = gson.toJson(person);
        System.out.println(personJsonString);
        Person person1 = gson.fromJson(personJsonString, Person.class);
        System.out.println(person1);
    }

    @Test
    public void test2(){
        List<Person> personList = new ArrayList<Person>();
        personList.add(new Person(1, "国歌"));
        personList.add(new Person(2, "康师傅"));

        Gson gson = new Gson();
        String personListJsonString = gson.toJson(personList);
        System.out.println(personListJsonString);
        List<Person> list = gson.fromJson(personListJsonString, new PersonListType().getType());
        System.out.println(list);
        Person person = list.get(0);
        System.out.println(person);

    }

    @Test
    public void Test3(){
        Map<Integer, Person> personMap = new HashMap<>();
        personMap.put(1, new Person(1, "国歌"));
        personMap.put(2, new Person(2, "康师傅"));
        Gson gson = new Gson();
        String personMapJsonString = gson.toJson(personMap);
        System.out.println(personMapJsonString);
//        HashMap<Integer, Person> map = gson.fromJson(personMapJsonString, new PersonMapType().getType());
        Map<Integer, Person> map = gson.fromJson(personMapJsonString, new TypeToken<HashMap<Integer, Person>>() {
        }.getType());
        System.out.println(map);
        Person person = map.get(1);
        System.out.println(person);
    }
}
