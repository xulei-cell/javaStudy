package com.atguigu.servlet;

import com.thoughtworks.xstream.core.util.Base64Encoder;
import org.apache.commons.io.IOUtils;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

public class Download extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String downloadFileName = "a.jpg";
        ServletContext servletContext = getServletContext();
        String mimeType = servletContext.getMimeType("/file/" + downloadFileName);
        System.out.println("下载的文件类型：" + mimeType);
        resp.setContentType(mimeType);
        if(req.getHeader("User-Agent").contains("FireFox")){
            resp.setHeader("Content-Disposition", "attachment; filename==?UTF-8?B?" + new Base64Encoder().encode("中国.jpg".getBytes(StandardCharsets.UTF_8)));
        }
        else {
            resp.setHeader("Content-Disposition", "attachment; filename=" + URLEncoder.encode("中国.jpg", "UTF-8"));
        }
        InputStream resourceAsStream = servletContext.getResourceAsStream("/file/" + downloadFileName);
        ServletOutputStream outputStream = resp.getOutputStream();
        IOUtils.copy(resourceAsStream, outputStream);

    }
}
