package com.atguigu.servlet;

import javax.servlet.*;
import javax.servlet.http.*;

import java.io.IOException;

public class ContextServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext servletContext = getServletContext();
        String username = servletContext.getInitParameter("username");
        System.out.println("context-param参数username的值是："+username);
        System.out.println("context-param参数password的值是："+servletContext.getInitParameter("password"));
        System.out.println("当前工程路径是："+servletContext.getContextPath());
        System.out.println("工程部署的路径是:"+servletContext.getRealPath("/"));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
